import express from "express";
import db from "../utils/db.js";
import { nanoid } from "nanoid";
import fetch from "node-fetch";

const router = express.Router();
router.post("/", async (req,res)=>{
  const { scenario, repo, notes, user, modules, consent } = req.body;
  if(!consent) return res.status(400).json({ok:false, error:'consent required'});
  const id = nanoid(10);
  const entry = {id, scenario, repo, notes, modules:modules||[], user, ts:Date.now()};
  db.data.scenarios.push(entry);
  await db.write();

  // Optional: trigger GH Actions if module present
  if((modules||[]).includes('git_actions') && repo && process.env.GH_TOKEN){
    try {
      await fetch(`https://api.github.com/repos/${repo}/actions/workflows/run-tests.yml/dispatches`, {
        method:'POST',
        headers:{'Authorization':`Bearer ${process.env.GH_TOKEN}`,'Accept':'application/vnd.github+json','Content-Type':'application/json'},
        body: JSON.stringify({ref:'main', inputs:{scenario:id}})
      });
    } catch(e){
      console.warn('gh dispatch failed', e.message);
    }
  }

  res.json({ok:true, id, message:'Scenario queued'});
});
export default router;
