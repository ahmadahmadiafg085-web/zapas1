# CyberSmart Hub (Extended Template)

این قالب نسخهٔ آماده (Option 2) است. شامل:
- Frontend: فایل استاتیک (index.html, style.css, app.js, i18n.json, logo.svg)
- Backend: Node.js (Express) skeleton با routeهای: start-scenario, shorten, upload, modules, health
- Multi-language (10 زبان پیش‌فرض)
- ماژول‌های پیشنهادی (۳۰ ماژول)
- جایگاه‌های خالی برای payment providers، ads، CDN، proxy pools، automation
- امنیت پایه: Helmet, CSP header, rate-limiting, simple DB (lowdb)

## سریع - نصب backend
1. در فولدر backend:
   ```bash
   npm install
   cp ../.env.example .env
   # و .env را با مقادیر خودت پر کن
   node server.js
   ```
2. Frontend را روی هاست استاتیک یا GitHub Pages آپلود کن، سپس URL صفحه را در BotFather -> Mini App -> Main URL قرار بده.

## نکات مهم امنیتی
- TLS اجباری (HTTPS)
- GH_TOKEN را با کمترین scope ذخیره کن
- قبل از اجرای تست‌ها، رضایت کتبی کاربر را ثبت کن
- فایل‌های آپلودی را قبل از اجرا اسکن کن

## گسترش
- هر ماژول می‌تواند route و UI جداگانه داشته باشد در `/backend/routes` و `/frontend` به صورت پلاگین اضافه شود.
- پرداخت: placeholders آماده‌اند؛ برای فعال‌سازی، اطلاعات provider را در settings وارد کن.

