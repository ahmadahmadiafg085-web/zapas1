import express from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import db from "../utils/db.js";
const router = express.Router();
const storagePath = process.env.STORAGE_PATH || './data/storage';
if(!fs.existsSync(storagePath)) fs.mkdirSync(storagePath, {recursive:true});
const upload = multer({ dest: storagePath + '/tmp' });

router.post("/", upload.single('file'), async (req,res)=>{
  if(!req.file) return res.status(400).json({error:'file missing'});
  const dest = path.join(storagePath, req.file.originalname);
  fs.renameSync(req.file.path, dest);
  db.data.uploads.push({name:req.file.originalname, path:dest, ts:Date.now()});
  await db.write();
  res.json({ok:true, name:req.file.originalname});
});

router.get("/list", (req,res)=> res.json(db.data.uploads||[]));
router.get("/download/:name", (req,res)=>{
  const p = db.data.uploads.find(x=>x.name===req.params.name);
  if(!p) return res.status(404).json({error:'not found'});
  res.download(p.path);
});
export default router;
