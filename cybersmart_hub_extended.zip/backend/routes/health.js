import express from "express";
import db from "../utils/db.js";
const router = express.Router();
router.get("/", (req,res)=> res.json({ok:true, ts:Date.now(), scenarios: db.data.scenarios.length}));
export default router;
