import express from "express";
const router = express.Router();
const MODULES = [
  // 30 modules (id, title, short)
  {id:"shortlink", title:"Shortlink & Analytics"},
  {id:"cdn_proxy", title:"CDN Proxy / Reroute"},
  {id:"loader_chain", title:"Loader Chain (nested loaders)"},
  {id:"nested_links", title:"Nested Links Manager"},
  {id:"script_store", title:"Script Versioning Store"},
  {id:"artifact_upload", title:"Artifact Uploader"},
  {id:"artifact_download", title:"Artifact Downloader"},
  {id:"git_actions", title:"GitHub Actions Trigger"},
  {id:"runner_sandbox", title:"Runner Sandbox Orchestrator"},
  {id:"browser_pentest", title:"Browser Pentest Tools"},
  {id:"windows_deploy", title:"Windows Packaging"},
  {id:"network_scan", title:"Network Scan (authorized)"},
  {id:"api_proxy", title:"Secure API Proxy"},
  {id:"oauth_connect", title:"OAuth Connectors"},
  {id:"jwt_auth", title:"JWT Auth"},
  {id:"hmac_sign", title:"HMAC Signing"},
  {id:"rate_limit", title:"Rate Limiter"},
  {id:"csp_enforce", title:"CSP Enforcer"},
  {id:"encrypted_logs", title:"Encrypted Logs"},
  {id:"kv_store", title:"Key-Value Store"},
  {id:"telemetry", title:"Telemetry"},
  {id:"consent_audit", title:"Consent Audit Trail"},
  {id:"shortcodes", title:"Shortcodes"},
  {id:"render_links", title:"Render Links"},
  {id:"cdn_reroute", title:"CDN Reroute / Fallback"},
  {id:"ip_geo", title:"IP Geolocation"},
  {id:"proxy_pool", title:"Proxy Pool Management"},
  {id:"threat_intel", title:"Threat Intelligence Feeds"},
  {id:"ai_benchmark", title:"AI/ML Benchmarks"},
  {id:"plugin_framework", title:"Plugin Framework"}
];
router.get("/", (req,res)=> res.json(MODULES));
export default router;
