import express from "express";
import db from "../utils/db.js";
import { nanoid } from "nanoid";
import slugify from "slugify";
const router = express.Router();
router.post("/", async (req,res)=>{
  const { url } = req.body;
  if(!url) return res.status(400).json({error:'url required'});
  const key = slugify(nanoid(6), {lower:true});
  db.data.shortlinks.push({key,url,created:Date.now()});
  await db.write();
  res.json({short: (process.env.BASE_URL||'') + '/r/' + key, key});
});
router.get("/:key",(req,res)=>{
  const item = db.data.shortlinks.find(x=>x.key===req.params.key);
  if(!item) return res.status(404).send('not found');
  res.redirect(item.url);
});
export default router;
