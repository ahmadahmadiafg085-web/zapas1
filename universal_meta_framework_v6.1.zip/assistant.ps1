# PowerShell assistant script
